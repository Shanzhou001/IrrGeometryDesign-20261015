#include "tchangeshowareadlg.h"
#include <qmessagebox.h>

TChangeShowareadlg::TChangeShowareadlg(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

TChangeShowareadlg::~TChangeShowareadlg()
{

}

void TChangeShowareadlg::init(float maxv,float minv)
{
	ui.MaxShowValue->setText(QString::number(maxv));
	ui.MinShowValue->setText(QString::number(minv));
}

void TChangeShowareadlg::on_OK_clicked()
{
	MaxShowValue=ui.MaxShowValue->text().toFloat();
	MinShowValue=ui.MinShowValue->text().toFloat();
	if(MaxShowValue<=MinShowValue)
	{
		QMessageBox::information(NULL,QString::fromLocal8Bit("��ʾ"),QString::fromLocal8Bit("�ֶβ�������"));//��Ϣ�Ի�����ʾ��ʾ�û�Υ������
	}
	else accept();
}

void TChangeShowareadlg::on_Cancel_clicked()
{
	reject();
}