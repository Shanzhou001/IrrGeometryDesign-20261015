#include "trosedividedlg.h"
#include <qmessagebox.h>

TRoseDividedlg::TRoseDividedlg(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

TRoseDividedlg::~TRoseDividedlg()
{

}

void TRoseDividedlg::init()
{
	ui.OffsetDivNumber->setText(QString::number(mOffsetDivNum));
	ui.AngleDivNumber->setText(QString::number(mAngleDivNum));
}
//ȷ��
void TRoseDividedlg::on_OK_clicked()
{
	mOffsetDivNum=ui.OffsetDivNumber->text().toInt();
	mAngleDivNum=ui.AngleDivNumber->text().toInt();
	if(mOffsetDivNum<=0||mAngleDivNum<=0)
	{
		QMessageBox::information(NULL,QString::fromLocal8Bit("��ʾ"),QString::fromLocal8Bit("�ֶβ�������"));//��Ϣ�Ի�����ʾ��ʾ�û�Υ������
	}
	else accept();
}

void TRoseDividedlg::on_Cancel_clicked()
{
	reject();
}