#include "tqfdividedlg.h"
#include <qmessagebox.h>

TQFDividedlg::TQFDividedlg(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

TQFDividedlg::~TQFDividedlg()
{

}

void TQFDividedlg::init()
{
	ui.OffsetDivNumber->setText(QString::number(mOffsetDivNum));
	ui.AngleDivNumber->setText(QString::number(mAngleDivNum));
	ui.MaxOffset->setText(QString::number(mMaxOffsetQf));
}

void TQFDividedlg::on_OK_clicked()
{
	mOffsetDivNum=ui.OffsetDivNumber->text().toInt();
	mAngleDivNum=ui.AngleDivNumber->text().toInt();
	mMaxOffsetQf=ui.MaxOffset->text().toInt();
	if(mOffsetDivNum<=0||mAngleDivNum<=0||mMaxOffsetQf<2)
	{
		QMessageBox::information(NULL,QString::fromLocal8Bit("��ʾ"),QString::fromLocal8Bit("�ֶβ�������"));//��Ϣ�Ի�����ʾ��ʾ�û�Υ������
	}
	else accept();
}

void TQFDividedlg::on_Cancel_clicked()
{
	reject();
}