#include "gcellgrid.h"
#include "../../core/gutils.h"
#include "gspsparam.h"
#include "../../core/gpoint3d.h"
//#include "gaabbox.h"
#include "../../core/gutils.h"
#include "../../io/sps/grlineset.h"
#include "../../io/sps/gslineset.h"
#include "../../io/sps/gproject.h"
#include "gspsparam.h"
//#include <qsqlquery.h>
//Added by qt3to4:
#include <Q3TextStream>

GCellGrid::GCellGrid()
{
	mGrid = NULL;
	mGridXY = NULL;// [3/20/2023 Liu Wei]
	mIlluEn = NULL;
	mRecvEn = NULL;
	mRecvOfsEn = NULL;
	mAccRecvOfsEn = NULL;
	mAccIlluEn = NULL;
	mAccRecvEn = NULL;
	mAccState = NULL;
	mRPtGrid = NULL;
	mMainRecvEn = NULL;
	mNumX = mNumY = 0;
	mGridX = mGridY = 0;
	mOfsNum = 0;

	mFold= NULL;
	setFold=0;

	//////////////////////////////////////////////////////////////////////////add by LiuWei
	mMaxoffset=0;
	mInMaxoffset=0;//inline��������ڼ��
	mCLMaxoffset=0;//Cline��������ڼ��
	//////////////////////////////////////////////////////////////////////////add by LiuWei
}

GCellGrid::~GCellGrid()
{
	clear();
}

void GCellGrid::clear()
{
	// ɾ��CellGrid����Ŀռ�
	if(mNumX > 0 && mNumY > 0)
	{
		gFree2(mGrid);
		gFree2(mGridXY);// [3/20/2023 Liu Wei]
		gFree2(mIlluEn);
		gFree2(mRecvEn);
		gFree2(mAccIlluEn);
		gFree2(mAccRecvEn);
		gFree2(mAccState);
		gFree2(mRPtGrid);
		gFree2(mRListGrid);
		gFree2(mMainRecvEn);

		//�Ի�����
		if(mFold!=NULL) gFree2(mFold);
		mNumX = mNumY = 0;
		setFold=0;
	}
}

void GCellGrid::zeroEn()
{
	gFill2(mIlluEn, 0.0f, mNumY, mNumX);
	gFill2(mRecvEn, 0.0f, mNumY, mNumX);
	//�Ի�����
	if(mFold!=NULL) gFill2(mFold,0, mNumY, mNumX);

}

void GCellGrid::zeroAccEn()
{
	gFill2(mAccIlluEn, 0.0f, mNumY, mNumX);
	gFill2(mAccRecvEn, 0.0f, mNumY, mNumX);
}

void GCellGrid::zeroAccState()
{
	memset(mAccState[0], 0, sizeof(int)*mNumX*mNumY);
}

void GCellGrid::nullRPtGrid()
{
	gFill2(mRPtGrid, (GRPoint *)NULL, mNumY, mNumX);
}

void GCellGrid::clearRListGrid()
{
	int i, j;
	for(i=0; i<mNumY; i++)
	{
		for(j=0; j<mNumX; j++)
		{
			mRListGrid[i][j].clear();
		}
	}
}

void GCellGrid::zeroMainRecvEn()
{
	gFill2(mMainRecvEn, 0.0f, mNumY, mNumX);
}

void GCellGrid::accIlluEn()
{
	for(int i=0; i<mNumY; i++)
	{
		for(int j=0; j<mNumX; j++)
		{
			mAccIlluEn[i][j] += mIlluEn[i][j];
		}
	}
}

void GCellGrid::accRecvEn()
{
	for(int i=0; i<mNumY; i++)
	{
		for(int j=0; j<mNumX; j++)
		{
			mAccRecvEn[i][j] += mRecvEn[i][j];
		}
	}
}

void GCellGrid::allocOfsEn(int nofs)
{
	freeOfsEn();
	gAlloc3(mRecvOfsEn, nofs, mNumY, mNumX);
	gAlloc3(mAccRecvOfsEn, nofs, mNumY, mNumX);
	mOfsNum = nofs;
}

void GCellGrid::freeOfsEn()
{
	if(mRecvOfsEn != NULL)
	{
		gFree3(mRecvOfsEn);
	}
	if(mAccRecvOfsEn != NULL)
	{
		gFree3(mAccRecvOfsEn);
	}
	mOfsNum = 0;
}

void GCellGrid::accOfsEn()
{
	int i, j, k;
	for(i=0; i<mOfsNum; i++)
	{
		for(j=0; j<mNumY; j++)
		{
			for(k=0; k<mNumX; k++)
			{
				mAccRecvOfsEn[i][j][k] += mRecvOfsEn[i][j][k];
			}
		}
	}
}

// ����������Ԫ����
// pSPSParam:			SPS��Ʋ���ָ��
// tx0, ty0:			��Ԫ����ƫ���һ���ĵ����Ծ������
// numX, numY:			��Ԫ������Ŀ
// gridX, gridY:		��Ԫ����ߴ�
void GCellGrid::create(GSPSParam *pSPSParam, float tx0, float ty0, int numX, int numY,
					   float gridX, float gridY)
{
	clear();

	// ����CellGrid�ռ�
	mNumX = numX;		mNumY = numY;
	mGridX = gridX;		mGridY = gridY;
	gAlloc2(mGrid, numY+1, numX+1);
	gAlloc2(mGridXY, numY+1, numX+1);// [3/20/2023 Liu Wei]
	gAlloc2(mIlluEn, mNumY, mNumX);
	gAlloc2(mRecvEn, mNumY, mNumX);
	gAlloc2(mAccIlluEn, mNumY, mNumX);
	gAlloc2(mAccRecvEn, mNumY, mNumX);
	gAlloc2(mAccState, mNumY, mNumX);
	gAlloc2(mRPtGrid, mNumY, mNumX);
	gAlloc2(mRListGrid, mNumY, mNumX);
	gAlloc2(mMainRecvEn, mNumY, mNumX);
//�Ի�����
	gAlloc2(mFold,mNumY,mNumX);
	setFold=0;

	// ����ز�����0
	zeroEn();
	zeroAccEn();
	zeroAccState();
	nullRPtGrid();
	zeroMainRecvEn();

	int i, j;
	float tx, ty, spsX, spsY;
	ty = ty0;

	// ѭ��������Ԫ������SPS����
	for(i=0; i<=mNumY; i++)
	{
		tx = tx0;
		for(j=0; j<=mNumX; j++)
		{
			mGridXY[i][j].set(tx,-1e10,ty);
			// ���������任ΪSPS����
			pSPSParam->transTosps(tx, ty, spsX, spsY);
			// Ϊ�������������
			mGrid[i][j].set(spsX, -1e10, spsY);
			tx += mGridX;
		}
		ty += mGridY;
	}

	//////////////////////////////////////////////////////////////////////////add by LiuWei
	mMaxoffset=0;
	mInMaxoffset=0;//inline��������ڼ��
	mCLMaxoffset=0;//Cline��������ڼ��
	//////////////////////////////////////////////////////////////////////////add by LiuWei
	// Ѱ����Ԫ�������귶Χ [Liu Wei 3/29/2023]
	float minbinX, minbinY, maxbinX, maxbinY;

	minbinX = minbinY = HUGE_VAL;
	maxbinX = maxbinY = -HUGE_VAL;

	for(i=0; i<=mNumY; i++)
	{
		for(j=0; j<=mNumX; j++)
		{
			if(mGrid[i][j].x() < minbinX) minbinX = mGrid[i][j].x();
			if(mGrid[i][j].x() > maxbinX) maxbinX = mGrid[i][j].x();
			if(mGrid[i][j].z() < minbinY) minbinY = mGrid[i][j].z();
			if(mGrid[i][j].z() > maxbinY) maxbinY = mGrid[i][j].z();
		}
	}
	mXmin=minbinX; mYmin=minbinY;
	mXmax=maxbinX; mYmax=maxbinY;
}

bool GCellGrid::save(QDataStream &stream)
{
	// �����������
	stream << mGridX << mGridY;
	stream << mNumX << mNumY;
	stream << mDiffX << mDiffY;
	// ��������ֽ�
	gSkipPadBytes(stream, GCELLGRID_PAD_SIZE);
	// �������������
	if(mNumX > 0 && mNumY > 0)
	{
		int i, j;
		
		for(i=0; i<=mNumY; i++)
		{
			for(j=0; j<=mNumX; j++)
			{
				stream << mGrid[i][j].x() << mGrid[i][j].z();
			}
		}
	}

	return true;
}

bool GCellGrid::load(QDataStream &stream)
{
	clear();

	// �����������
	stream >> mGridX >> mGridY;
	stream >> mNumX >> mNumY;
	stream >> mDiffX >> mDiffY;
	// ��������ֽ�
	gSkipPadBytes(stream, GCELLGRID_PAD_SIZE);
	
	if(mNumX > 0 && mNumY > 0)
	{
		// ����ռ�
		gAlloc2(mGrid, mNumY+1, mNumX+1);
		gAlloc2(mIlluEn, mNumY, mNumX);
		gAlloc2(mRecvEn, mNumY, mNumX);
		gAlloc2(mAccIlluEn, mNumY, mNumX);
		gAlloc2(mAccRecvEn, mNumY, mNumX);
		gAlloc2(mAccState, mNumY, mNumX);
		gAlloc2(mRPtGrid, mNumY, mNumX);
		gAlloc2(mRListGrid, mNumY, mNumX);
		gAlloc2(mMainRecvEn, mNumY, mNumX);
		//�Ի�����
		gAlloc2(mFold,mNumY,mNumX);
		// ������0
		zeroEn();
		zeroAccEn();
		zeroAccState();
		nullRPtGrid();
		zeroMainRecvEn();
		// ������������
		int i, j;
		for(i=0; i<=mNumY; i++)
		{
			for(j=0; j<=mNumX; j++)
			{
				stream >> mGrid[i][j][0] >> mGrid[i][j][2];
				mGrid[i][j][1] = -1e10;
			}
		}
	}

	return true;
}

bool GCellGrid::exportInEn(const QString &fileName, uint surfaceID)
{
	QFile file(fileName);
	if(!file.open(QIODevice::WriteOnly)) return false;

	Q3TextStream stream(&file);
	stream.setEncoding(Q3TextStream::Locale);
	QString line;

	stream << QString::fromLocal8Bit("// ��Ԫ���������ļ�\r\n");
	stream << QString::fromLocal8Bit("// Ŀ�Ĳ�ID\r\n");
	stream << QString::fromLocal8Bit("// ��ԪX�ߴ�\t��ԪY�ߴ�\r\n");
	stream << QString::fromLocal8Bit("// X��Ԫ��Ŀ\tY��Ԫ��Ŀ\r\n");
	stream << QString::fromLocal8Bit("// ��Ԫ�������Ͻ�X\tY\t��Ԫ����Ƕ�\r\n");
	stream << QString::fromLocal8Bit("// ��ԪX\t��ԪY\t��ԪZ\t��Ԫ��������\r\n");

	line.sprintf("%d\r\n", surfaceID);
	stream << line;
	line.sprintf("%f\t%f\r\n", mGridX, mGridY);
	stream << line;
	line.sprintf("%d\t%d\r\n", mNumX, mNumY);
	stream << line;

	if(mNumX <= 0 || mNumY <= 0)
	{
		stream << "0\t0";		// �����һ��x, y����
		file.close();
		return true;
	}
	
	// ��¼��һ�������Ͻ�����
	GProject *pProject = GProject::getCurrentProject();
	GSPSParam *pSPSParam = pProject->getSPSParam();
	line.sprintf("%f\t%f\t%f\r\n", mGrid[0][0].x(), mGrid[0][0].z(), pSPSParam->mAf*RADIAN_TO_ANGLE);
	stream << line;
	int i, j;
	float hx, hy;
	hx = mGridX / 2;
	hy = mGridY / 2;
	
	for(i=0; i<mNumY; i++)
	{
		for(j=0; j<mNumX; j++)
		{
			if(mAccIlluEn[i][j] > 0 || mAccRecvEn[i][j] > 0)
			{
				line.sprintf("%.2f\t%.2f\t%.2f\t%f\r\n", mGrid[i][j].x()+hx,
					mGrid[i][j].z()+hy, mGrid[i][j].y(), mAccIlluEn[i][j]);
				stream << line;
			}
		}
	}

	file.close();

	return true;
}

bool GCellGrid::exportRecvEn(const QString &fileName, uint surfaceID)
{
	QFile file(fileName);
	if(!file.open(QIODevice::WriteOnly)) return false;

	Q3TextStream stream(&file);
	stream.setEncoding(Q3TextStream::Locale);
	QString line;

	stream << QString::fromLocal8Bit("// ��Ԫ���������ļ�\r\n");
	stream << QString::fromLocal8Bit("// Ŀ�Ĳ�ID\r\n");
	stream << QString::fromLocal8Bit("// ��ԪX�ߴ�\t��ԪY�ߴ�\r\n");
	stream << QString::fromLocal8Bit("// X��Ԫ��Ŀ\tY��Ԫ��Ŀ\r\n");
	stream << QString::fromLocal8Bit("// ��Ԫ�������Ͻ�X\tY\t��Ԫ�Ƕ�\r\n");
	stream << QString::fromLocal8Bit("// ��ԪX\t��ԪY\t��ԪZ\t��Ԫ��������\r\n");

	line.sprintf("%d\r\n", surfaceID);
	stream << line;
	line.sprintf("%f\t%f\r\n", mGridX, mGridY);
	stream << line;
	line.sprintf("%d\t%d\r\n", mNumX, mNumY);
	stream << line;

	if(mNumX <= 0 || mNumY <= 0)
	{
		stream << "0\t0";		// �����һ��x, y����
		file.close();
		return true;
	}
	
	// ��¼��һ�������Ͻ����꼰�Ƕ�
	GProject *pProject = GProject::getCurrentProject();
	GSPSParam *pSPSParam = pProject->getSPSParam();
	line.sprintf("%f\t%f\t%f\r\n", mGrid[0][0].x(), mGrid[0][0].z(), pSPSParam->mAf*RADIAN_TO_ANGLE);
	stream << line;
	int i, j;
	float hx, hy;
	hx = mGridX / 2;
	hy = mGridY / 2;
	
	for(i=0; i<mNumY; i++)
	{
		for(j=0; j<mNumX; j++)
		{
			if(mAccIlluEn[i][j] > 0 || mAccRecvEn[i][j] > 0)
			{
				line.sprintf("%.2f\t%.2f\t%.2f\t%f\r\n", mGrid[i][j].x()+hx,
					mGrid[i][j].z()+hy, mGrid[i][j].y(), mAccRecvEn[i][j]);
				stream << line;
			}
		}
	}

	file.close();

	return true;
}

bool GCellGrid::exportMainRecvEn(Q3TextStream &stream, GSPoint *pSPoint)
{
	int i, j;
	float hx, hy;
	hx = mGridX / 2;
	hy = mGridY / 2;

	QString line;

	for(i=0; i<mNumY; i++)
	{
		for(j=0; j<mNumX; j++)
		{
			GRPoint *pRPoint = mRPtGrid[i][j];
			if(pRPoint != NULL)
			{
				line.sprintf("%-16s%-8s%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%-16s%-8s%.2f\t%.2f\t%.2f\t%f\r\n",
					(const char *)pSPoint->getLineName(), (const char *)pSPoint->getPointNum(),
					pSPoint->getSPSX(), pSPoint->getSPSY(), pSPoint->getSPSZ(),
					mGrid[i][j].x()+hx, mGrid[i][j].z()+hy, mGrid[i][j].y(),
					(const char *)pRPoint->getLineName(), (const char *)pRPoint->getPointNum(),
					pRPoint->getSPSX(), pRPoint->getSPSY(), pRPoint->getSPSZ(),
					mMainRecvEn[i][j]);
				stream << line;
			}
		}
	}
	return true;
}

bool GCellGrid::exportOfsEn(Q3TextStream *streams, GSPoint *pSPoint)
{
	int i, j, k;
	float hx, hy, en;
	hx = mGridX / 2;
	hy = mGridY / 2;
	
	QString line, str;
	
	if(pSPoint != NULL)
	{
		for(i=0; i<mNumY; i++)
		{
			for(j=0; j<mNumX; j++)
			{
				line.sprintf("%-16s%-8s%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f",
					(const char *)pSPoint->getLineName(), (const char *)pSPoint->getPointNum(),
					pSPoint->getSPSX(), pSPoint->getSPSY(), pSPoint->getSPSZ(),
							mGrid[i][j].x()+hx, mGrid[i][j].z()+hy, mGrid[i][j].y());
				for(k=0; k<mOfsNum; k++)
				{
					en = mRecvOfsEn[k][i][j];
					if(en > 1e-7)
					{
						streams[k] << line;
						str.sprintf("\t%.f\r\n", en);
						streams[k] << str;
					}
				}
			}
		}
	}
	else
	{
		for(i=0; i<mNumY; i++)
		{
			for(j=0; j<mNumX; j++)
			{
				line.sprintf("%.2f\t%.2f\t%.2f",
					mGrid[i][j].x()+hx, mGrid[i][j].z()+hy, mGrid[i][j].y());
				for(k=0; k<mOfsNum; k++)
				{
					en = mAccRecvOfsEn[k][i][j];
					if(en > 1e-7)
					{
						streams[k] << line;
						str.sprintf("\t%.f\r\n", en);
						streams[k] << str;
					}
				}
			}
		}
	}
	return true;
}

void GCellGrid::calculateCoverCount()
{
	GProject *pProject = GProject::getCurrentProject();
	if (!pProject || !mFold || mNumX <= 0 || mNumY <= 0 || !mGridXY) return;

	int r,s; 
	for(r=0; r<mNumY; r++)
		for(s=0; s<mNumX; s++)
			mFold[r][s] = 0;
	mMaxoffset = 0;
	mInMaxoffset = 0;
	mCLMaxoffset = 0;
	GRLineSet *rLineSet = (pProject->mIsNewImfo && pProject->getRLineSetNew() && pProject->getRLineSetNew()->count() > 0)
	                      ? pProject->getRLineSetNew()
	                      : ((pProject->getRLineSet() && pProject->getRLineSet()->count() > 0) ? pProject->getRLineSet() : pProject->getRLineSetNew());
	GShotSet *tsl = (pProject->mIsNewImfo && pProject->getShotSetNew() && pProject->getShotSetNew()->count() > 0)
	                ? pProject->getShotSetNew()
	                : ((pProject->getShotSet() && pProject->getShotSet()->count() > 0) ? pProject->getShotSet() : pProject->getShotSetNew());
	if (!rLineSet || !tsl || tsl->count() == 0) return;

#pragma omp parallel for //���м������
	for(s=0; s<tsl->count(); s++)
	{
		GShot *sl = tsl->get(s);
		float offsetx = sl->getSPoint()->getRandomOffsetX();
		float offsety = sl->getSPoint()->getRandomOffsetY();

		//float sx = sl->getSPoint()->getSPSX()+offsetx;//����ʦ��ԭʼ����
		//float sy = sl->getSPoint()->getSPSY()+offsety;//����ʦ��ԭʼ����

		float sx = sl->getSPoint()->getX()+offsetx;// [3/20/2023 Liu Wei]
		float sy = sl->getSPoint()->getY()+offsety;// [3/20/2023 Liu Wei]

		int test_count=sl->getTrcCount();// ���ټ��� [Liu Wei 6/21/2023]
		for(int si=0; si<sl->getTrcCount(); si++)
		{
			
			GRPoint *rpoint = sl->getRPointByTrcIndex(si,rLineSet);
			if(rpoint==NULL)
				continue;
			//float rx = rpoint->getSPSX()+offsetx;//����ʦ��ԭʼ����
			//float ry = rpoint->getSPSY()+offsety;//����ʦ��ԭʼ����

			float rx = rpoint->getX()+offsetx;// [3/20/2023 Liu Wei]
			float ry = rpoint->getY()+offsety;// [3/20/2023 Liu Wei]

			float tempcmpx = (rx+sx)/2;
			float tempcmpy = (ry+sy)/2;

			int i = (tempcmpx-mGridXY[0][0].x())/mGridX;// [3/20/2023 Liu Wei]
			int j = (tempcmpy-mGridXY[0][0].z())/mGridY;// [3/20/2023 Liu Wei]

			//�Ի�����
			int offset=sqrt((float)((sx-rx)*(sx-rx)+(sy-ry)*(sy-ry)));//�ڼ��
			#pragma omp critical(gcell_maxoff)
			{ if(offset>mMaxoffset) mMaxoffset=offset; }//������ڼ��
			int tInoffset=abs(sx-rx);
			#pragma omp critical(gcell_maxoff)
			{ if(tInoffset>mInMaxoffset) mInMaxoffset=tInoffset; }
			int tCLoffset=abs(sy-ry);
			#pragma omp critical(gcell_maxoff)
			{ if(tCLoffset>mCLMaxoffset) mCLMaxoffset=tCLoffset; }
			//�Ի�����

			if(i<0||j<0)
				continue; 	
			if(i>mNumX-1||j>mNumY-1)
				continue; 
			#pragma omp atomic
			mFold[j][i]++;
			// (removed racy debug read-back of mFold[j][i])
		}
	}

	float max = 0;
	for(r=0; r<mNumY; r++)
	{
		for(s=0; s<mNumX; s++)
		{
			if(max<mFold[r][s])
				max = mFold[r][s];
		}
	}

	//�Ի�����
	//�ҵ������Ǵ����ķ�Χ
	// ���ڷǹ���۲�ϵͳ���ԣ���󸲸Ǵ������ܲ������۵������Ǵ������� [Liu Wei 4/8/2023]
	int target_folds=max*0.9;
	int begini=0;int endi=mNumX-1;
	int beginj=0;int endj=mNumY-1;
	for(r=1; r<mNumY-1; r++)
	{
		for(s=1; s<mNumX-1; s++)
		{
			if(mFold[r][s]==target_folds && mFold[r-1][s-1]<target_folds && begini==0 && beginj==0) 
			{
				begini=s; beginj=r;
			}
			if(mFold[r][s]==target_folds && mFold[r+1][s+1]<target_folds) //|| mFold[r][s+1]<max || mFold[r+1][s]<max
			{// Ҳ���ܱ�֤�ٷ�֮���ҵ����������� [Liu Wei 4/6/2023]
				if (s>begini && r>beginj)
				{
					endi=s; endj=r;
				}
			}
			//if(mFold[r][s]==max && mFold[r+1][s+1]<max) //����ʦ��Դ�룺����ֿ�ʼ������Χ��ȵ�Bug�����
			//{
			//	endi=s; endj=r;
			//}
		}
	}
	pProject->setFoldArea(begini,endi,beginj,endj);//�����ǵķ�Χ
	//�ҵ������Ǵ����ķ�Χ

	//�Ի�����
	pProject->getAttrAnalyzeParam()->mBeginAreaOffset=mMaxoffset/3;//�ڼ����������������߽��ʼ��
	pProject->getAttrAnalyzeParam()->mEndAreaOffset=2*mMaxoffset/3;
	pProject->getAttrAnalyzeParam()->mBeginAreaInOffset=mInMaxoffset/3;//OVT������inline����߽��ʼ��
	pProject->getAttrAnalyzeParam()->mEndAreaInOffset=2*mInMaxoffset/3;
	pProject->getAttrAnalyzeParam()->mBeginAreaCLOffset=mCLMaxoffset/3;//OVT������Crline����߽��ʼ��
	pProject->getAttrAnalyzeParam()->mEndAreaCLOffset=2*mCLMaxoffset/3;
	pProject->getAttrAnalyzeParam()->mInMaxOffset=mInMaxoffset;
	pProject->getAttrAnalyzeParam()->mCLMaxOffset=mCLMaxoffset;
	//�Ի�����
}
