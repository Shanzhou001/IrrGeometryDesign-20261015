/****************************************************************************
** GPtrVector.h   1.0   edited Aug 19 06:00 $
**
** Definition of GPtrVector pointer based template class
**
** Created : def
**
** Copyright (C) 1992-2000 Trolltech AS.  All rights reserved.
**
**********************************************************************/

#ifndef GPTRVECTOR_H
#define GPTRVECTOR_H

#include <stdio.h>

typedef unsigned int uint;

template<class type>
class GPtrVector	//ָ�������б�
{
private:
	type **m_pdata;
	uint m_size;
	uint m_count;
	bool m_autoDelete;			//�Զ�ɾ��ָ���ڴ��־
private:
	void sift( uint k, uint m, int (* compare)(type *d1, type *d2) );	//������ɸ�Ӻ���
public:
	GPtrVector<type>();				//����ձ�
	GPtrVector<type>( uint size );	//Ԥ�ȷ���ռ�size
	~GPtrVector<type>();

	inline uint size() { return m_size; }
	inline uint count() { return m_count; }
	inline bool isEmpty() { return m_count == 0; }
	inline bool isNull() { return m_pdata == NULL; }

	inline void setAutoDelete( bool enable ) { m_autoDelete = enable; }
	inline bool autoDelete() { return m_autoDelete; }

	bool prepend( type *data );	//ǰ��
	bool append( type *data );	//���
	bool insert( uint index, type *data );	//����
	uint insertByOrder( type *data, int (* compare)(type *d1, type *d2) ); //���벢����

	bool removeFirst();			//ɾ����һԪ��
	bool removeLast();			//ɾ��βԪ��
	bool remove( uint index );	//ɾ��index�ϵ�Ԫ��
	void clear();				//���

	inline type * at( uint index ) const;	//����index�ϵ�Ԫ��
	inline bool set( uint index, type *data );	//����index�ϵ�Ԫ��
	inline type * operator []( uint index ) const { return at( index ); }	

	void resize( uint size );	//���·���ռ�
	void trunclate() { resize(count()); }

	int find( type *d, uint index = 0 );	//���Բ���
	int find( type *d, int (* compare)(type *d1, type *d2), uint index = 0 );

	int bsearch( type *d, int (* compare)(type *d1, type *d2) );	//���ֲ���

	void heapsort( int (* compare)(type *d1, type *d2) );	//������
};

template<class type>
GPtrVector<type>::GPtrVector()
{
	m_pdata = NULL;
	m_size = 0;
	m_count = 0;
	m_autoDelete = false;
}

template<class type>
GPtrVector<type>::GPtrVector( uint size )
{
	if( size > 0 ) m_pdata = new type *[size];
	else m_pdata = NULL;
	m_size = size;
	m_count = 0;
	m_autoDelete = false;
}

template<class type>
GPtrVector<type>::~GPtrVector()
{
	if( m_pdata != NULL ) 
	{
		clear();
		delete []m_pdata;
	}
}

template<class type>
void GPtrVector<type>::clear()
{
	if( m_autoDelete )
	{
		for( uint i=0; i<m_count; i++ )
		{
			delete m_pdata[i];
		}
	}
	m_count = 0;
}

template<class type>
void GPtrVector<type>::resize( uint size )
{
	uint i;
	type **pdata;
	if( size > m_size )			//���ſռ�
	{
		pdata = new type *[size];
		for( i=0; i<m_count; i++ ) pdata[i] = m_pdata[i];
		delete []m_pdata;
		m_pdata = pdata;
	}
	else if( size < m_size )	//��С�ռ�
	{
		if( size == 0 ) 
		{
			clear();
			delete []m_pdata;
			m_pdata = NULL;
			m_count = 0;
		}
		else
		{
			pdata = new type *[size];
			for( i=0; i<m_count&&i<size; i++ ) pdata[i] = m_pdata[i];
			m_count = i;
			if( m_autoDelete )
			{
				for( ;i<m_count; i++ ) delete m_pdata[i];
			}
			delete []m_pdata;
			m_pdata = pdata;
		}
	}
	m_size = size;
}

template<class type>
bool GPtrVector<type>::append( type *data )
{
	if( m_count == m_size )		//��Ҫ���ſռ�
	{
		type **pdata;
		m_size += m_size/2;
		m_size = (m_size/8+1)*8;	//����8�߾�����ڴ���Ƭ
		pdata = new type *[m_size];
		for( uint i=0; i<m_count; i++ ) pdata[i] = m_pdata[i];
		if( m_pdata != NULL ) delete []m_pdata;
		m_pdata = pdata;
	}
	m_pdata[m_count++] = data;
	return true;
}

template<class type>
bool GPtrVector<type>::prepend( type *data )
{
	uint i;
	if( m_count == m_size )		//��Ҫ���ſռ�
	{
		type **pdata;
		m_size += m_size/2;
		m_size = (m_size/8+1)*8;	//����8�߾�����ڴ���Ƭ
		pdata = new type *[m_size];
		for( i=0; i<m_count; i++ ) pdata[i+1] = m_pdata[i];
		if( m_pdata != NULL ) delete []m_pdata;
		m_pdata = pdata;
	}
	else 
	{
		for( i=m_count; i>0; i-- ) m_pdata[i] = m_pdata[i-1];
	}
	m_pdata[0] = data;
	m_count++;
	return true;
}

template<class type>
bool GPtrVector<type>::insert( uint index, type *data )
{
	if( index > m_count ) return false;

	uint i;
	if( m_count == m_size )		//��Ҫ���ſռ�
	{
		type **pdata;
		m_size += m_size/2;
		m_size = (m_size/8+1)*8;	//����8�߾�����ڴ���Ƭ
		pdata = new type *[m_size];
		for( i=0; i<index; i++ ) pdata[i] = m_pdata[i];
		for( i=index; i<m_count; i++ ) pdata[i+1] = m_pdata[i];
		if( m_pdata != NULL ) delete []m_pdata;
		m_pdata = pdata;
	}
	else
	{
		for( i=m_count; i>index; i-- ) m_pdata[i] = m_pdata[i-1];
	}
	m_pdata[index] = data;
	m_count++;
	return true;
}

template<class type>
uint GPtrVector<type>::insertByOrder( type *data, int (* compare)(type *d1, type *d2) )
{
	int i, index;
	if( m_count == m_size )		//��Ҫ���ſռ�
	{
		type **pdata;
		m_size += m_size/2;
		m_size = (m_size/8+1)*8;	//����8�߾�����ڴ���Ƭ
		pdata = new type *[m_size];
		for( i=m_count-1; i>=0; i-- )
		{
			if( compare( data, m_pdata[i] ) >= 0 ) break;
			pdata[i+1] = m_pdata[i];
		}
		index = i+1;
		pdata[index] = data;
		for( ; i>=0; i-- ) pdata[i] = m_pdata[i];
		if( m_pdata != NULL ) delete []m_pdata;
		m_pdata = pdata;
	}
	else
	{
		for( i=m_count-1; i>=0; i-- )
		{
			if( compare( data, m_pdata[i] ) >= 0 ) break;
			m_pdata[i+1] = m_pdata[i];
		}
		index = i+1;
		m_pdata[index] = data;
	}
	m_count++;
	return index;
}

template<class type>
bool GPtrVector<type>::removeFirst()
{
	if( m_count == 0 ) return false;

	if( m_autoDelete ) delete m_pdata[0];
	for( uint i=1; i<m_count; i++ ) m_pdata[i-1] = m_pdata[i];	
	m_count--;
	return true;
}

template<class type>
bool GPtrVector<type>::removeLast()
{
	if( m_count == 0 ) return false;

	m_count--;
	if( m_autoDelete ) delete m_pdata[m_count];
	return true;
}

template<class type>
bool GPtrVector<type>::remove( uint index )
{
	if( index >= m_count ) return false;

	if( m_autoDelete ) delete m_pdata[index];
	m_count--;
	for( uint i=index; i<m_count; i++ ) m_pdata[i] = m_pdata[i+1];
	return true;
}

template<class type>
type * GPtrVector<type>::at( uint index ) const
{
	if( index >= m_count ) return NULL;
	else return m_pdata[index];
}

template<class type>
bool GPtrVector<type>::set( uint index, type *data )
{
	if( index >= m_count ) return false;
	m_pdata[index] = data;
	return true;
}

template<class type>
int GPtrVector<type>::find( type *d, uint index )
{
	for( uint i=index; i<m_count; i++ )
	{
		if( m_pdata[i] == d ) return i;
	}
	return -1;
}

template<class type>
int GPtrVector<type>::find( type *d, int (* compare)(type *d1, type *d2), uint index )
{
	for( uint i=index; i<m_count; i++ )
	{
		if( compare(m_pdata[i], d) == 0 ) return i;
	}
	return -1;
}

template<class type>
int GPtrVector<type>::bsearch( type *d, int (* compare)(type *d1, type *d2) )
{
	uint i, first, last;

	first = 0;	
	last = m_count-1;
	while( first <= last )
	{
		i = (first+last)/2;
		int r = compare(m_pdata[i], d);
		if( r > 0 ) last = i-1;
		else if( r == 0 ) return i;
		else first = i+1;
	}
	
	return -1;
}

template<class type>
void GPtrVector<type>::sift( uint k, uint m, int (* compare)(type *d1, type *d2) )
{
    uint i,j;
    type *rp;

    i = k;	j = 2*i+1;	rp = m_pdata[k];
    while( j <= m ) 
	{
	    if( j < m && compare(m_pdata[j], m_pdata[j+1]) < 0 ) j++;
	    if( compare(m_pdata[j], rp) < 0 ) break;
	    else 
		{ 
			m_pdata[i] = m_pdata[j]; 
			i = j; 
			j = 2*i+1; 
		}
	}
    m_pdata[i] = rp;
}	

template<class type>
void GPtrVector<type>::heapsort( int (* compare)(type *d1, type *d2) )
{
	int i;
	type *rp;

    for( i=m_count/2-1; i>=0; i--) sift( i, m_count-1, compare );
    for( i=m_count-1; i>=1; i--)
	{
	    rp = m_pdata[0];
	    m_pdata[0] = m_pdata[i];
	    m_pdata[i] = rp;
	    sift( 0, i-1, compare );
	}
}

#endif