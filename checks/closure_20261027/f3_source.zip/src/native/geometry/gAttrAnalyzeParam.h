#ifndef GATTRANALYZE_PARAM_H
#define GATTRANALYZE_PARAM_H

#include <qfile.h>
#include <qdatastream.h>

//#define GFORWARDPARAM_PAD_SIZE 512

// ����SPS��������
class GAttrAnalyzeParam
{
public:
	bool mAllAzimuth,mEqualAzimuth;
	int mEqualNumAzimuth;
	bool mAllOffset,mEqualOffset;
	int mEqualNumOffset;
	bool mAreaOffset;
	int mBeginAreaOffset,mEndAreaOffset;

	bool mEqualInOffset,mAreaInOffset;
	int mEqualNumInOffset,mBeginAreaInOffset,mEndAreaInOffset;
	bool mEqualCLOffset,mAreaCLOffset;
	int mEqualNumCLOffset,mBeginAreaCLOffset,mEndAreaCLOffset;
	int mInMaxOffset,mCLMaxOffset;
	// ����ʦ�����ò�������
	int mRealBeginAreaInOffset,mRealEndAreaInOffset;
	int mRealBeginAreaCLOffset,mRealEndAreaCLOffset;

public:
	GAttrAnalyzeParam();

	void reset();

	// ����
	bool save(QDataStream &stream);
	// ����
	bool load(QDataStream &stream);
};

#endif